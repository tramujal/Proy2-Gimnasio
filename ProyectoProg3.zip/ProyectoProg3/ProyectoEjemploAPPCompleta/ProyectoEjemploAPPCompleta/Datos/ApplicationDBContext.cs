﻿using System;
using System.Collections.Generic;
using EjemploAPPCompleta.Models;
using Microsoft.EntityFrameworkCore;
using ProyectoEjemploAPPCompleta.Models;

namespace EjemploAPPCompleta.Datos
{
    public class ApplicationDBContext : DbContext
    {
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> opciones) : base(opciones) { }
        public DbSet<Local> Locales { get; set; }
        public DbSet<TipoMaquina> TipoMaquinas { get; set; }
        public DbSet<Maquina> Maquinas { get; set; }
        public DbSet<Ejercicio> Ejercicios { get; set; }
        public DbSet<Rutina> Rutinas { get; set; }
        public DbSet<RutinaEjercicio> RutinaEjercicios { get; set; }
        public DbSet<Socio> Socios { get; set; }
        public DbSet<SocioRutina> SocioRutinas { get; set; }
        public DbSet<RutinaControl> RutinaControles { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<RutinaEjercicio>()
                .HasKey(re => new { re.IdRutina, re.IdEjercicio });

            modelBuilder.Entity<SocioRutina>()
                .HasKey(sr => new { sr.IdSocio, sr.IdRutina });

            modelBuilder.Entity<Maquina>()
                .HasOne(m => m.Local)
                .WithMany(l => l.MaquinasPosibles)
                .HasForeignKey(m => m.IdLocal)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Maquina>()
                .HasOne(m => m.TipoMaquinaPosibles)
                .WithMany(tm => tm.Maquinas)
                .HasForeignKey(m => m.IdTipoMaq)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Ejercicio>()
                .HasOne(e => e.TipoMaquina)
                .WithMany(tm => tm.Ejercicios)
                .HasForeignKey(e => e.IdTipoMaq)
                .OnDelete(DeleteBehavior.SetNull);

            modelBuilder.Entity<RutinaEjercicio>()
                .HasOne(re => re.Rutina)
                .WithMany(r => r.RutinaEjercicios)
                .HasForeignKey(re => re.IdRutina)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<RutinaEjercicio>()
                .HasOne(re => re.Ejercicio)
                .WithMany(e => e.RutinaEjercicios)
                .HasForeignKey(re => re.IdEjercicio)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<SocioRutina>()
                .HasOne(sr => sr.Socio)
                .WithMany(s => s.SocioRutinas)
                .HasForeignKey(sr => sr.IdSocio)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<SocioRutina>()
                .HasOne(sr => sr.Rutina)
                .WithMany(r => r.SocioRutinas)
                .HasForeignKey(sr => sr.IdRutina)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<RutinaControl>()
                .HasOne(rc => rc.Rutina)
                .WithMany(r => r.RutinaControles)
                .HasForeignKey(rc => rc.IdRutina)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Local>()
                .HasIndex(l => l.Nombre)
                .IsUnique();

            modelBuilder.Entity<TipoMaquina>()
                .HasIndex(tm => tm.Nombre)
                .IsUnique();

            modelBuilder.Entity<Rutina>()
                .HasIndex(r => r.Nombre)
                .IsUnique();
        }
    }
}