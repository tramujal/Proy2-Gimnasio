﻿using EjemploAPPCompleta.Datos;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc;
using ProyectoEjemploAPPCompleta.Models;
using Microsoft.EntityFrameworkCore;

namespace ProyectoEjemploAPPCompleta.Controllers
{
    public class EjercicioController : Controller
    {
        private readonly ApplicationDBContext _context;

        public EjercicioController(ApplicationDBContext context)
        {
            _context = context;
        }

        public IActionResult List()
        {
            var ejercicios = _context.Ejercicios.Include(e => e.TipoMaquina).ToList();
            return View(ejercicios);
        }

        public IActionResult Add()
        {
            ViewData["IdTipoMaq"] = new SelectList(_context.TipoMaquinas, "Id", "Nombre");
            return View();
        }

        [HttpPost]
        public IActionResult Add(Ejercicio ejercicio)
        {
            if (ModelState.IsValid)
            {
                _context.Ejercicios.Add(ejercicio);
                _context.SaveChanges();
                return RedirectToAction("List");
            }
            ViewData["IdTipoMaq"] = new SelectList(_context.TipoMaquinas, "Id", "Nombre", ejercicio.IdTipoMaq);
            return View(ejercicio);
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            var ejercicio = _context.Ejercicios.Find(id);
            if (ejercicio != null)
            {
                _context.Ejercicios.Remove(ejercicio);
                _context.SaveChanges();
            }
            return RedirectToAction("List");
        }

        public IActionResult Update(int id)
        {
            var ejercicio = _context.Ejercicios.Find(id);
            if (ejercicio == null) return NotFound();
            ViewData["IdTipoMaq"] = new SelectList(_context.TipoMaquinas, "Id", "Nombre", ejercicio.IdTipoMaq);
            return View(ejercicio);
        }

        [HttpPost]
        public IActionResult Update(Ejercicio ejercicio)
        {
            if (ModelState.IsValid)
            {
                _context.Ejercicios.Update(ejercicio);
                _context.SaveChanges();
                return RedirectToAction("List");
            }
            ViewData["IdTipoMaq"] = new SelectList(_context.TipoMaquinas, "Id", "Nombre", ejercicio.IdTipoMaq);
            return View(ejercicio);
        }
    }

}
