﻿using EjemploAPPCompleta.Datos;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc;
using ProyectoEjemploAPPCompleta.Models;
using Microsoft.EntityFrameworkCore;

namespace ProyectoEjemploAPPCompleta.Controllers
{
    public class MaquinaController : Controller
    {
        private readonly ApplicationDBContext _context;

        public MaquinaController(ApplicationDBContext context)
        {
            _context = context;
        }

        public IActionResult List()
        {
            var maquinas = _context.Maquinas.Include(m => m.Local).Include(m => m.TipoMaquina).ToList();
            return View(maquinas);
        }

        public IActionResult Add()
        {
            ViewData["IdLocal"] = new SelectList(_context.Locales, "Id", "Nombre");
            ViewData["IdTipoMaq"] = new SelectList(_context.TipoMaquinas, "Id", "Nombre");
            return View();
        }

        [HttpPost]
        public IActionResult Add(Maquina maquina)
        {
            if (ModelState.IsValid)
            {
                _context.Maquinas.Add(maquina);
                _context.SaveChanges();
                return RedirectToAction("List");
            }
            ViewData["IdLocal"] = new SelectList(_context.Locales, "Id", "Nombre", maquina.IdLocal);
            ViewData["IdTipoMaq"] = new SelectList(_context.TipoMaquinas, "Id", "Nombre", maquina.IdTipoMaq);
            return View(maquina);
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            var maquina = _context.Maquinas.Find(id);
            if (maquina != null)
            {
                _context.Maquinas.Remove(maquina);
                _context.SaveChanges();
            }
            return RedirectToAction("List");
        }

        public IActionResult Update(int id)
        {
            var maquina = _context.Maquinas.Find(id);
            if (maquina == null) return NotFound();
            ViewData["IdLocal"] = new SelectList(_context.Locales, "Id", "Nombre", maquina.IdLocal);
            ViewData["IdTipoMaq"] = new SelectList(_context.TipoMaquinas, "Id", "Nombre", maquina.IdTipoMaq);
            return View(maquina);
        }

        [HttpPost]
        public IActionResult Update(Maquina maquina)
        {
            if (ModelState.IsValid)
            {
                _context.Maquinas.Update(maquina);
                _context.SaveChanges();
                return RedirectToAction("List");
            }
            ViewData["IdLocal"] = new SelectList(_context.Locales, "Id", "Nombre", maquina.IdLocal);
            ViewData["IdTipoMaq"] = new SelectList(_context.TipoMaquinas, "Id", "Nombre", maquina.IdTipoMaq);
            return View(maquina);
        }
    }

}
