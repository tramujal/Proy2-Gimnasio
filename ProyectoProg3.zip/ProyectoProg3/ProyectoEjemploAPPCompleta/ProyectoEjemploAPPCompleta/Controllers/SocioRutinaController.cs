﻿using EjemploAPPCompleta.Datos;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc;
using ProyectoEjemploAPPCompleta.Models;
using Microsoft.EntityFrameworkCore;

namespace ProyectoEjemploAPPCompleta.Controllers
{
    public class SocioRutinaController : Controller
    {
        private readonly ApplicationDBContext _context;

        public SocioRutinaController(ApplicationDBContext context)
        {
            _context = context;
        }

        public IActionResult List()
        {
            var socioRutinas = _context.SocioRutinas
                .Include(sr => sr.Socio)
                .Include(sr => sr.Rutina)
                .ToList();
            return View(socioRutinas);
        }

        public IActionResult Add()
        {
            ViewData["IdSocio"] = new SelectList(_context.Socios, "Id", "Nombre");
            ViewData["IdRutina"] = new SelectList(_context.Rutinas, "Id", "Nombre");
            return View();
        }

        [HttpPost]
        public IActionResult Add(SocioRutina socioRutina)
        {
            if (ModelState.IsValid)
            {
                _context.SocioRutinas.Add(socioRutina);
                _context.SaveChanges();
                return RedirectToAction("List");
            }
            ViewData["IdSocio"] = new SelectList(_context.Socios, "Id", "Nombre", socioRutina.IdSocio);
            ViewData["IdRutina"] = new SelectList(_context.Rutinas, "Id", "Nombre", socioRutina.IdRutina);
            return View(socioRutina);
        }

        [HttpPost]
        public IActionResult Delete(int idSocio, int idRutina)
        {
            var socioRutina = _context.SocioRutinas
                .FirstOrDefault(sr => sr.IdSocio == idSocio && sr.IdRutina == idRutina);
            if (socioRutina != null)
            {
                _context.SocioRutinas.Remove(socioRutina);
                _context.SaveChanges();
            }
            return RedirectToAction("List");
        }

        public IActionResult Update(int idSocio, int idRutina)
        {
            var socioRutina = _context.SocioRutinas
                .FirstOrDefault(sr => sr.IdSocio == idSocio && sr.IdRutina == idRutina);
            if (socioRutina == null) return NotFound();
            ViewData["IdSocio"] = new SelectList(_context.Socios, "Id", "Nombre", socioRutina.IdSocio);
            ViewData["IdRutina"] = new SelectList(_context.Rutinas, "Id", "Nombre", socioRutina.IdRutina);
            return View(socioRutina);
        }

        [HttpPost]
        public IActionResult Update(SocioRutina socioRutina)
        {
            if (ModelState.IsValid)
            {
                _context.SocioRutinas.Update(socioRutina);
                _context.SaveChanges();
                return RedirectToAction("List");
            }
            ViewData["IdSocio"] = new SelectList(_context.Socios, "Id", "Nombre", socioRutina.IdSocio);
            ViewData["IdRutina"] = new SelectList(_context.Rutinas, "Id", "Nombre", socioRutina.IdRutina);
            return View(socioRutina);
        }
    }

}
