﻿using System;
using EjemploAPPCompleta.Datos;
using EjemploAPPCompleta.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ProyectoEjemploAPPCompleta.Models;

namespace ProyectoEjemploAPPCompleta.Controllers
{
    public class FiltrosController : Controller
    {
        private readonly ApplicationDBContext _context;

        public FiltrosController(ApplicationDBContext context)
        {
            _context = context;
        }

        // Filtro 1: Obtener socios que no han hecho rutinas que contengan ejercicios con una máquina específica
        public IActionResult SociosSinRutinasConMaquina()
        {
            ViewBag.MaquinasPosibles = new SelectList(_context.Maquinas, "Id", "Nombre");
            return View(new List<Socio>());
        }

        [HttpPost]
        public IActionResult SociosSinRutinasConMaquina(int idMaquina)
        {
            // Obtener los IDs de los ejercicios que usan la máquina especificada
            var ejerciciosConMaquina = _context.Ejercicios
                .Where(e => e.IdTipoMaq == idMaquina)
                .Select(e => e.Id)
                .ToList();

            // Obtener los IDs de las rutinas que contienen esos ejercicios
            var rutinasConEjerciciosDeMaquina = _context.RutinaEjercicios
                .Where(re => ejerciciosConMaquina.Contains(re.IdEjercicio))
                .Select(re => re.IdRutina)
                .Distinct()
                .ToList();

            // Obtener los IDs de los socios que tienen esas rutinas asignadas
            var sociosConRutinasDeMaquina = _context.SocioRutinas
                .Where(sr => rutinasConEjerciciosDeMaquina.Contains(sr.IdRutina))
                .Select(sr => sr.IdSocio)
                .Distinct()
                .ToList();

            // Obtener los socios que no tienen esas rutinas asignadas
            var sociosSinRutinasConMaquina = _context.Socios
                .Where(s => !sociosConRutinasDeMaquina.Contains(s.Id))
                .ToList();

            ViewBag.MaquinasPosibles = new SelectList(_context.Maquinas, "Id", "Nombre");
            return View(sociosSinRutinasConMaquina);
        }

        // Filtro 2: Mostrar los 5 socios con más rutinas asignadas
        public IActionResult Top5SociosConMasRutinas()
        {
            var topSocios = _context.SocioRutinas
                .GroupBy(sr => sr.IdSocio)
                .Select(g => new
                {
                    SocioId = g.Key,
                    CantidadRutinas = g.Count()
                })
                .OrderByDescending(s => s.CantidadRutinas)
                .Take(5)
                .ToList();

            // Obtener la información completa de los socios top 5
            var topSociosCompleto = _context.Socios
                .Where(s => topSocios.Select(t => t.SocioId).Contains(s.Id))
                .ToList();

            return View(topSociosCompleto);
        }
    }

}

