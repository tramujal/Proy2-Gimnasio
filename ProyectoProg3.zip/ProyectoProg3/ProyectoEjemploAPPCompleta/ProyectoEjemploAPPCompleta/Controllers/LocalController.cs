﻿using System;
using EjemploAPPCompleta.Datos;
using EjemploAPPCompleta.Models;
using Microsoft.AspNetCore.Mvc;
using ProyectoEjemploAPPCompleta.Models;

namespace EjemploAPPCompleta.Controllers
{
    public class LocalController : Controller
    {
        private readonly ApplicationDBContext _context;

        public LocalController(ApplicationDBContext context)
        {
            _context = context;
        }

        public IActionResult List()
        {
            var locales = _context.Locales.ToList();
            return View(locales);
        }

        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(Local local)
        {
            if (_context.Locales.Any(l => l.Nombre == local.Nombre))
            {
                ViewBag.ErrorMessage = "El nombre del local ya existe";
                return View();
            }
            if (ModelState.IsValid)
            {
                _context.Locales.Add(local);
                _context.SaveChanges();
                return RedirectToAction("List");
            }
            return View();
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            var local = _context.Locales.Find(id);
            if (local != null)
            {
                _context.Locales.Remove(local);
                _context.SaveChanges();
            }
            return RedirectToAction("List");
        }

        public IActionResult Update(int id)
        {
            var local = _context.Locales.Find(id);
            if (local == null) return NotFound();
            return View(local);
        }

        [HttpPost]
        public IActionResult Update(Local local)
        {
            if (ModelState.IsValid)
            {
                _context.Locales.Update(local);
                _context.SaveChanges();
                return RedirectToAction("List");
            }
            return View(local);
        }
    }
}
