﻿using EjemploAPPCompleta.Datos;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc;
using ProyectoEjemploAPPCompleta.Models;
using Microsoft.EntityFrameworkCore;

namespace ProyectoEjemploAPPCompleta.Controllers
{
    public class RutinaEjercicioController : Controller
    {
        private readonly ApplicationDBContext _context;

        public RutinaEjercicioController(ApplicationDBContext context)
        {
            _context = context;
        }

        public IActionResult List()
        {
            var rutinaEjercicios = _context.RutinaEjercicios
                .Include(re => re.Rutina)
                .Include(re => re.Ejercicio)
                .ToList();
            return View(rutinaEjercicios);
        }

        public IActionResult Add()
        {
            ViewData["IdRutina"] = new SelectList(_context.Rutinas, "Id", "Nombre");
            ViewData["IdEjercicio"] = new SelectList(_context.Ejercicios, "Id", "Nombre");
            return View();
        }

        [HttpPost]
        public IActionResult Add(RutinaEjercicio rutinaEjercicio)
        {
            if (ModelState.IsValid)
            {
                _context.RutinaEjercicios.Add(rutinaEjercicio);
                _context.SaveChanges();
                return RedirectToAction("List");
            }
            ViewData["IdRutina"] = new SelectList(_context.Rutinas, "Id", "Nombre", rutinaEjercicio.IdRutina);
            ViewData["IdEjercicio"] = new SelectList(_context.Ejercicios, "Id", "Nombre", rutinaEjercicio.IdEjercicio);
            return View(rutinaEjercicio);
        }

        [HttpPost]
        public IActionResult Delete(int idRutina, int idEjercicio)
        {
            var rutinaEjercicio = _context.RutinaEjercicios
                .FirstOrDefault(re => re.IdRutina == idRutina && re.IdEjercicio == idEjercicio);
            if (rutinaEjercicio != null)
            {
                _context.RutinaEjercicios.Remove(rutinaEjercicio);
                _context.SaveChanges();
            }
            return RedirectToAction("List");
        }

        public IActionResult Update(int idRutina, int idEjercicio)
        {
            var rutinaEjercicio = _context.RutinaEjercicios
                .FirstOrDefault(re => re.IdRutina == idRutina && re.IdEjercicio == idEjercicio);
            if (rutinaEjercicio == null) return NotFound();
            ViewData["IdRutina"] = new SelectList(_context.Rutinas, "Id", "Nombre", rutinaEjercicio.IdRutina);
            ViewData["IdEjercicio"] = new SelectList(_context.Ejercicios, "Id", "Nombre", rutinaEjercicio.IdEjercicio);
            return View(rutinaEjercicio);
        }

        [HttpPost]
        public IActionResult Update(RutinaEjercicio rutinaEjercicio)
        {
            if (ModelState.IsValid)
            {
                _context.RutinaEjercicios.Update(rutinaEjercicio);
                _context.SaveChanges();
                return RedirectToAction("List");
            }
            ViewData["IdRutina"] = new SelectList(_context.Rutinas, "Id", "Nombre", rutinaEjercicio.IdRutina);
            ViewData["IdEjercicio"] = new SelectList(_context.Ejercicios, "Id", "Nombre", rutinaEjercicio.IdEjercicio);
            return View(rutinaEjercicio);
        }
    }

}
