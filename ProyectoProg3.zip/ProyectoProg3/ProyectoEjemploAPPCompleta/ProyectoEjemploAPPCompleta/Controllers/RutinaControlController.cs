﻿using EjemploAPPCompleta.Datos;
using EjemploAPPCompleta.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ProyectoEjemploAPPCompleta.Controllers
{
    public class RutinaControlController : Controller
    {
        private readonly ApplicationDBContext _context;

        public RutinaControlController(ApplicationDBContext context)
        {
            _context = context;
        }

        public IActionResult List()
        {
            var rutinaControles = _context.RutinaControles
                .Include(rc => rc.Rutina)
                .ToList();
            return View(rutinaControles);
        }

        public IActionResult Add()
        {
            ViewData["IdRutina"] = new SelectList(_context.Rutinas, "Id", "Nombre");
            return View();
        }

        [HttpPost]
        public IActionResult Add(RutinaControl rutinaControl)
        {
            if (ModelState.IsValid)
            {
                _context.RutinaControles.Add(rutinaControl);
                _context.SaveChanges();
                return RedirectToAction("List");
            }
            ViewData["IdRutina"] = new SelectList(_context.Rutinas, "Id", "Nombre", rutinaControl.IdRutina);
            return View(rutinaControl);
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            var rutinaControl = _context.RutinaControles.Find(id);
            if (rutinaControl != null)
            {
                _context.RutinaControles.Remove(rutinaControl);
                _context.SaveChanges();
            }
            return RedirectToAction("List");
        }

        public IActionResult Update(int id)
        {
            var rutinaControl = _context.RutinaControles.Find(id);
            if (rutinaControl == null) return NotFound();
            ViewData["IdRutina"] = new SelectList(_context.Rutinas, "Id", "Nombre", rutinaControl.IdRutina);
            return View(rutinaControl);
        }

        [HttpPost]
        public IActionResult Update(RutinaControl rutinaControl)
        {
            if (ModelState.IsValid)
            {
                _context.RutinaControles.Update(rutinaControl);
                _context.SaveChanges();
                return RedirectToAction("List");
            }
            ViewData["IdRutina"] = new SelectList(_context.Rutinas, "Id", "Nombre", rutinaControl.IdRutina);
            return View(rutinaControl);
        }
    }

}
