﻿using EjemploAPPCompleta.Datos;
using Microsoft.AspNetCore.Mvc;
using ProyectoEjemploAPPCompleta.Models;

namespace ProyectoEjemploAPPCompleta.Controllers
{
    public class SocioController : Controller
    {
        private readonly ApplicationDBContext _context;

        public SocioController(ApplicationDBContext context)
        {
            _context = context;
        }

        public IActionResult List()
        {
            var socios = _context.Socios.ToList();
            return View(socios);
        }

        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(Socio socio)
        {
            if (ModelState.IsValid)
            {
                _context.Socios.Add(socio);
                _context.SaveChanges();
                return RedirectToAction("List");
            }
            return View(socio);
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            var socio = _context.Socios.Find(id);
            if (socio != null)
            {
                _context.Socios.Remove(socio);
                _context.SaveChanges();
            }
            return RedirectToAction("List");
        }

        public IActionResult Update(int id)
        {
            var socio = _context.Socios.Find(id);
            if (socio == null) return NotFound();
            return View(socio);
        }

        [HttpPost]
        public IActionResult Update(Socio socio)
        {
            if (ModelState.IsValid)
            {
                _context.Socios.Update(socio);
                _context.SaveChanges();
                return RedirectToAction("List");
            }
            return View(socio);
        }
    }

}
