﻿using EjemploAPPCompleta.Datos;
using Microsoft.AspNetCore.Mvc;
using ProyectoEjemploAPPCompleta.Models;

namespace ProyectoEjemploAPPCompleta.Controllers
{
    public class TipoMaquinaController : Controller
    {
        private readonly ApplicationDBContext _context;

        public TipoMaquinaController(ApplicationDBContext context)
        {
            _context = context;
        }

        public IActionResult List()
        {
            var tipoMaquinas = _context.TipoMaquinas.ToList();
            return View(tipoMaquinas);
        }

        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(TipoMaquina tipoMaquina)
        {
            if (_context.TipoMaquinas.Any(tm => tm.Nombre == tipoMaquina.Nombre))
            {
                ViewBag.ErrorMessage = "El nombre del tipo de máquina ya existe";
                return View();
            }
            if (ModelState.IsValid)
            {
                _context.TipoMaquinas.Add(tipoMaquina);
                _context.SaveChanges();
                return RedirectToAction("List");
            }
            return View();
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            var tipoMaquina = _context.TipoMaquinas.Find(id);
            if (tipoMaquina != null)
            {
                _context.TipoMaquinas.Remove(tipoMaquina);
                _context.SaveChanges();
            }
            return RedirectToAction("List");
        }

        public IActionResult Update(int id)
        {
            var tipoMaquina = _context.TipoMaquinas.Find(id);
            if (tipoMaquina == null) return NotFound();
            return View(tipoMaquina);
        }

        [HttpPost]
        public IActionResult Update(TipoMaquina tipoMaquina)
        {
            if (ModelState.IsValid)
            {
                _context.TipoMaquinas.Update(tipoMaquina);
                _context.SaveChanges();
                return RedirectToAction("List");
            }
            return View(tipoMaquina);
        }
    }

}
