﻿using EjemploAPPCompleta.Datos;
using EjemploAPPCompleta.Models;
using Microsoft.AspNetCore.Mvc;

namespace ProyectoEjemploAPPCompleta.Controllers
{
    public class RutinaController : Controller
    {
        private readonly ApplicationDBContext _context;

        public RutinaController(ApplicationDBContext context)
        {
            _context = context;
        }

        public IActionResult List()
        {
            var rutinas = _context.Rutinas.ToList();
            return View(rutinas);
        }

        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(Rutina rutina)
        {
            if (_context.Rutinas.Any(r => r.Nombre == rutina.Nombre))
            {
                ViewBag.ErrorMessage = "El nombre de la rutina ya existe";
                return View();
            }
            if (ModelState.IsValid)
            {
                _context.Rutinas.Add(rutina);
                _context.SaveChanges();
                return RedirectToAction("List");
            }
            return View();
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            var rutina = _context.Rutinas.Find(id);
            if (rutina != null)
            {
                _context.Rutinas.Remove(rutina);
                _context.SaveChanges();
            }
            return RedirectToAction("List");
        }

        public IActionResult Update(int id)
        {
            var rutina = _context.Rutinas.Find(id);
            if (rutina == null) return NotFound();
            return View(rutina);
        }

        [HttpPost]
        public IActionResult Update(Rutina rutina)
        {
            if (ModelState.IsValid)
            {
                _context.Rutinas.Update(rutina);
                _context.SaveChanges();
                return RedirectToAction("List");
            }
            return View(rutina);
        }
    }

}
