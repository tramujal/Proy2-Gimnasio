﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProyectoEjemploAPPCompleta.Migrations
{

    public partial class restrictdelete : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Cambiar las claves foráneas para restringir la eliminación
            migrationBuilder.DropForeignKey(
                name: "FK_SOCIOS_LOCALES_idLocal",
                table: "SOCIOS");

            migrationBuilder.DropForeignKey(
                name: "FK_MAQUINAS_TIPOMAQUINAS_idTipoMaq",
                table: "MAQUINAS");

            migrationBuilder.DropForeignKey(
                name: "FK_MAQUINAS_LOCALES_idLocal",
                table: "MAQUINAS");

            migrationBuilder.DropForeignKey(
                name: "FK_EJERCICIOS_TIPOMAQUINAS_idTipoMaq",
                table: "EJERCICIOS");

            migrationBuilder.DropForeignKey(
                name: "FK_RUTINASEJERCICIOS_RUTINAS_idRutina",
                table: "RUTINASEJERCICIOS");

            migrationBuilder.DropForeignKey(
                name: "FK_RUTINASEJERCICIOS_EJERCICIOS_idEjercicio",
                table: "RUTINASEJERCICIOS");

            migrationBuilder.DropForeignKey(
                name: "FK_SOCIOSRUTINAS_SOCIOS_idSocio",
                table: "SOCIOSRUTINAS");

            migrationBuilder.DropForeignKey(
                name: "FK_SOCIOSRUTINAS_RUTINAS_idRutina",
                table: "SOCIOSRUTINAS");

            migrationBuilder.DropForeignKey(
                name: "FK_RUTINAS_CONTROL_RUTINAS_idRutina",
                table: "RUTINAS_CONTROL");

            // Agregar nuevas claves foráneas con restricción de eliminación
            migrationBuilder.AddForeignKey(
                name: "FK_SOCIOS_LOCALES_idLocal",
                table: "SOCIOS",
                column: "idLocal",
                principalTable: "LOCALES",
                principalColumn: "idLocal",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_MAQUINAS_TIPOMAQUINAS_idTipoMaq",
                table: "MAQUINAS",
                column: "idTipoMaq",
                principalTable: "TIPOMAQUINAS",
                principalColumn: "idTipoMaq",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_MAQUINAS_LOCALES_idLocal",
                table: "MAQUINAS",
                column: "idLocal",
                principalTable: "LOCALES",
                principalColumn: "idLocal",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_EJERCICIOS_TIPOMAQUINAS_idTipoMaq",
                table: "EJERCICIOS",
                column: "idTipoMaq",
                principalTable: "TIPOMAQUINAS",
                principalColumn: "idTipoMaq",
                onDelete: ReferentialAction.SetNull);

            migrationBuilder.AddForeignKey(
                name: "FK_RUTINASEJERCICIOS_RUTINAS_idRutina",
                table: "RUTINASEJERCICIOS",
                column: "idRutina",
                principalTable: "RUTINAS",
                principalColumn: "idRutina",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_RUTINASEJERCICIOS_EJERCICIOS_idEjercicio",
                table: "RUTINASEJERCICIOS",
                column: "idEjercicio",
                principalTable: "EJERCICIOS",
                principalColumn: "idEjercicio",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_SOCIOSRUTINAS_SOCIOS_idSocio",
                table: "SOCIOSRUTINAS",
                column: "idSocio",
                principalTable: "SOCIOS",
                principalColumn: "idSocio",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_SOCIOSRUTINAS_RUTINAS_idRutina",
                table: "SOCIOSRUTINAS",
                column: "idRutina",
                principalTable: "RUTINAS",
                principalColumn: "idRutina",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_RUTINAS_CONTROL_RUTINAS_idRutina",
                table: "RUTINAS_CONTROL",
                column: "idRutina",
                principalTable: "RUTINAS",
                principalColumn: "idRutina",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Restaurar las claves foráneas originales con eliminación en cascada
            migrationBuilder.DropForeignKey(
                name: "FK_SOCIOS_LOCALES_idLocal",
                table: "SOCIOS");

            migrationBuilder.DropForeignKey(
                name: "FK_MAQUINAS_TIPOMAQUINAS_idTipoMaq",
                table: "MAQUINAS");

            migrationBuilder.DropForeignKey(
                name: "FK_MAQUINAS_LOCALES_idLocal",
                table: "MAQUINAS");

            migrationBuilder.DropForeignKey(
                name: "FK_EJERCICIOS_TIPOMAQUINAS_idTipoMaq",
                table: "EJERCICIOS");

            migrationBuilder.DropForeignKey(
                name: "FK_RUTINASEJERCICIOS_RUTINAS_idRutina",
                table: "RUTINASEJERCICIOS");

            migrationBuilder.DropForeignKey(
                name: "FK_RUTINASEJERCICIOS_EJERCICIOS_idEjercicio",
                table: "RUTINASEJERCICIOS");

            migrationBuilder.DropForeignKey(
                name: "FK_SOCIOSRUTINAS_SOCIOS_idSocio",
                table: "SOCIOSRUTINAS");

            migrationBuilder.DropForeignKey(
                name: "FK_SOCIOSRUTINAS_RUTINAS_idRutina",
                table: "SOCIOSRUTINAS");

            migrationBuilder.DropForeignKey(
                name: "FK_RUTINAS_CONTROL_RUTINAS_idRutina",
                table: "RUTINAS_CONTROL");

            // Agregar las claves foráneas originales con eliminación en cascada
            migrationBuilder.AddForeignKey(
                name: "FK_SOCIOS_LOCALES_idLocal",
                table: "SOCIOS",
                column: "idLocal",
                principalTable: "LOCALES",
                principalColumn: "idLocal",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_MAQUINAS_TIPOMAQUINAS_idTipoMaq",
                table: "MAQUINAS",
                column: "idTipoMaq",
                principalTable: "TIPOMAQUINAS",
                principalColumn: "idTipoMaq",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_MAQUINAS_LOCALES_idLocal",
                table: "MAQUINAS",
                column: "idLocal",
                principalTable: "LOCALES",
                principalColumn: "idLocal",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_EJERCICIOS_TIPOMAQUINAS_idTipoMaq",
                table: "EJERCICIOS",
                column: "idTipoMaq",
                principalTable: "TIPOMAQUINAS",
                principalColumn: "idTipoMaq",
                onDelete: ReferentialAction.SetNull);

            migrationBuilder.AddForeignKey(
                name: "FK_RUTINASEJERCICIOS_RUTINAS_idRutina",
                table: "RUTINASEJERCICIOS",
                column: "idRutina",
                principalTable: "RUTINAS",
                principalColumn: "idRutina",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_RUTINASEJERCICIOS_EJERCICIOS_idEjercicio",
                table: "RUTINASEJERCICIOS",
                column: "idEjercicio",
                principalTable: "EJERCICIOS",
                principalColumn: "idEjercicio",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_SOCIOSRUTINAS_SOCIOS_idSocio",
                table: "SOCIOSRUTINAS",
                column: "idSocio",
                principalTable: "SOCIOS",
                principalColumn: "idSocio",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_SOCIOSRUTINAS_RUTINAS_idRutina",
                table: "SOCIOSRUTINAS",
                column: "idRutina",
                principalTable: "RUTINAS",
                principalColumn: "idRutina",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_RUTINAS_CONTROL_RUTINAS_idRutina",
                table: "RUTINAS_CONTROL",
                column: "idRutina",
                principalTable: "RUTINAS",
                principalColumn: "idRutina",
                onDelete: ReferentialAction.Cascade);
        }
    }

}
