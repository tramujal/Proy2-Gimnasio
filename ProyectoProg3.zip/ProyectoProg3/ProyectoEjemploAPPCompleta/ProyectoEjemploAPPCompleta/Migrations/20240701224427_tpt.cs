﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProyectoEjemploAPPCompleta.Migrations
{
    public partial class tpt : Migration
    {
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        // Creación de la tabla LOCALES
        migrationBuilder.CreateTable(
            name: "LOCALES",
            columns: table => new
            {
                idLocal = table.Column<int>(type: "int", nullable: false)
                    .Annotation("SqlServer:Identity", "1, 1"),
                nomLocal = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                ciudadLocal = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                dirLocal = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                telLocal = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                responsLocal = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_LOCALES", x => x.idLocal);
            });

        // Creación de la tabla TIPOMAQUINAS
        migrationBuilder.CreateTable(
            name: "TIPOMAQUINAS",
            columns: table => new
            {
                idTipoMaq = table.Column<int>(type: "int", nullable: false)
                    .Annotation("SqlServer:Identity", "1, 1"),
                nomTipoMaq = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_TIPOMAQUINAS", x => x.idTipoMaq);
            });

        // Creación de la tabla SOCIOS
        migrationBuilder.CreateTable(
            name: "SOCIOS",
            columns: table => new
            {
                idSocio = table.Column<int>(type: "int", nullable: false)
                    .Annotation("SqlServer:Identity", "1, 1"),
                tipoSocio = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                nomSocio = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                telSocio = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                mailSocio = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                fNacSocio = table.Column<DateTime>(type: "date", nullable: false),
                idLocal = table.Column<int>(type: "int", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_SOCIOS", x => x.idSocio);
                table.ForeignKey(
                    name: "FK_SOCIOS_LOCALES_idLocal",
                    column: x => x.idLocal,
                    principalTable: "LOCALES",
                    principalColumn: "idLocal",
                    onDelete: ReferentialAction.Cascade);
            });

        // Creación de la tabla MAQUINAS
        migrationBuilder.CreateTable(
            name: "MAQUINAS",
            columns: table => new
            {
                idMaq = table.Column<int>(type: "int", nullable: false)
                    .Annotation("SqlServer:Identity", "1, 1"),
                idTipoMaq = table.Column<int>(type: "int", nullable: false),
                idLocal = table.Column<int>(type: "int", nullable: false),
                fechaCompra = table.Column<DateTime>(type: "date", nullable: false),
                precioCompra = table.Column<decimal>(type: "decimal(10,2)", nullable: false),
                vidaUtil = table.Column<int>(type: "int", nullable: false),
                estado = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_MAQUINAS", x => x.idMaq);
                table.ForeignKey(
                    name: "FK_MAQUINAS_TIPOMAQUINAS_idTipoMaq",
                    column: x => x.idTipoMaq,
                    principalTable: "TIPOMAQUINAS",
                    principalColumn: "idTipoMaq",
                    onDelete: ReferentialAction.Cascade);
                table.ForeignKey(
                    name: "FK_MAQUINAS_LOCALES_idLocal",
                    column: x => x.idLocal,
                    principalTable: "LOCALES",
                    principalColumn: "idLocal",
                    onDelete: ReferentialAction.Cascade);
            });

        // Creación de la tabla RUTINAS
        migrationBuilder.CreateTable(
            name: "RUTINAS",
            columns: table => new
            {
                idRutina = table.Column<int>(type: "int", nullable: false)
                    .Annotation("SqlServer:Identity", "1, 1"),
                descRutina = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                tipoRutina = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                califRutinaPromedio = table.Column<decimal>(type: "decimal(3,2)", nullable: false, defaultValue: 0)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_RUTINAS", x => x.idRutina);
            });

        // Creación de la tabla EJERCICIOS
        migrationBuilder.CreateTable(
            name: "EJERCICIOS",
            columns: table => new
            {
                idEjercicio = table.Column<int>(type: "int", nullable: false)
                    .Annotation("SqlServer:Identity", "1, 1"),
                descEjercicio = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                linkVideoEjercicio = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                idTipoMaq = table.Column<int>(type: "int", nullable: true)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_EJERCICIOS", x => x.idEjercicio);
                table.ForeignKey(
                    name: "FK_EJERCICIOS_TIPOMAQUINAS_idTipoMaq",
                    column: x => x.idTipoMaq,
                    principalTable: "TIPOMAQUINAS",
                    principalColumn: "idTipoMaq",
                    onDelete: ReferentialAction.SetNull);
            });

        // Creación de la tabla RUTINASEJERCICIOS
        migrationBuilder.CreateTable(
            name: "RUTINASEJERCICIOS",
            columns: table => new
            {
                idRutina = table.Column<int>(type: "int", nullable: false),
                idEjercicio = table.Column<int>(type: "int", nullable: false),
                cantEjercicio = table.Column<int>(type: "int", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_RUTINASEJERCICIOS", x => new { x.idRutina, x.idEjercicio });
                table.ForeignKey(
                    name: "FK_RUTINASEJERCICIOS_RUTINAS_idRutina",
                    column: x => x.idRutina,
                    principalTable: "RUTINAS",
                    principalColumn: "idRutina",
                    onDelete: ReferentialAction.Cascade);
                table.ForeignKey(
                    name: "FK_RUTINASEJERCICIOS_EJERCICIOS_idEjercicio",
                    column: x => x.idEjercicio,
                    principalTable: "EJERCICIOS",
                    principalColumn: "idEjercicio",
                    onDelete: ReferentialAction.Cascade);
            });

        // Creación de la tabla SOCIOSRUTINAS
        migrationBuilder.CreateTable(
            name: "SOCIOSRUTINAS",
            columns: table => new
            {
                idSocio = table.Column<int>(type: "int", nullable: false),
                idRutina = table.Column<int>(type: "int", nullable: false),
                fechaInicio = table.Column<DateTime>(type: "date", nullable: false),
                fechaFin = table.Column<DateTime>(type: "date", nullable: false),
                calificación = table.Column<int>(type: "int", nullable: true)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_SOCIOSRUTINAS", x => new { x.idSocio, x.idRutina, x.fechaInicio });
                table.ForeignKey(
                    name: "FK_SOCIOSRUTINAS_SOCIOS_idSocio",
                    column: x => x.idSocio,
                    principalTable: "SOCIOS",
                    principalColumn: "idSocio",
                    onDelete: ReferentialAction.Cascade);
                table.ForeignKey(
                    name: "FK_SOCIOSRUTINAS_RUTINAS_idRutina",
                    column: x => x.idRutina,
                    principalTable: "RUTINAS",
                    principalColumn: "idRutina",
                    onDelete: ReferentialAction.Cascade);
            });

        // Creación de la tabla RUTINAS_CONTROL
        migrationBuilder.CreateTable(
            name: "RUTINAS_CONTROL",
            columns: table => new
            {
                idRutina = table.Column<int>(type: "int", nullable: false),
                fechaControl = table.Column<DateTime>(type: "date", nullable: false),
                resultadoControl = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_RUTINAS_CONTROL", x => new { x.idRutina, x.fechaControl });
                table.ForeignKey(
                    name: "FK_RUTINAS_CONTROL_RUTINAS_idRutina",
                    column: x => x.idRutina,
                    principalTable: "RUTINAS",
                    principalColumn: "idRutina",
                    onDelete: ReferentialAction.Cascade);
            });

        // Creación de índices
        migrationBuilder.CreateIndex(
            name: "IX_SOCIOS_idLocal",
            table: "SOCIOS",
            column: "idLocal");

        migrationBuilder.CreateIndex(
            name: "IX_MAQUINAS_idTipoMaq",
            table: "MAQUINAS",
            column: "idTipoMaq");

        migrationBuilder.CreateIndex(
            name: "IX_MAQUINAS_idLocal",
            table: "MAQUINAS",
            column: "idLocal");

        migrationBuilder.CreateIndex(
            name: "IX_EJERCICIOS_idTipoMaq",
            table: "EJERCICIOS",
            column: "idTipoMaq");

        migrationBuilder.CreateIndex(
            name: "IX_RUTINASEJERCICIOS_idEjercicio",
            table: "RUTINASEJERCICIOS",
            column: "idEjercicio");

        migrationBuilder.CreateIndex(
            name: "IX_SOCIOSRUTINAS_idRutina",
            table: "SOCIOSRUTINAS",
            column: "idRutina");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        // Eliminación de las tablas en orden de dependencia
        migrationBuilder.DropTable(
            name: "SOCIOSRUTINAS");

        migrationBuilder.DropTable(
            name: "RUTINASEJERCICIOS");

        migrationBuilder.DropTable(
            name: "RUTINAS_CONTROL");

        migrationBuilder.DropTable(
            name: "SOCIOS");

        migrationBuilder.DropTable(
            name: "EJERCICIOS");

        migrationBuilder.DropTable(
            name: "RUTINAS");

        migrationBuilder.DropTable(
            name: "MAQUINAS");

        migrationBuilder.DropTable(
            name: "TIPOMAQUINAS");

        migrationBuilder.DropTable(
            name: "LOCALES");
    }
}
}
