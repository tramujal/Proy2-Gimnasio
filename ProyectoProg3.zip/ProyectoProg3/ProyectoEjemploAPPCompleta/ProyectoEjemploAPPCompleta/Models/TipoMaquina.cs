﻿using System.ComponentModel.DataAnnotations;

namespace ProyectoEjemploAPPCompleta.Models
{
    public class TipoMaquina
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre del tipo de máquina es obligatorio")]
        [StringLength(100, ErrorMessage = "El nombre no puede tener más de 100 caracteres")]
        public required string Nombre { get; set; }

        // Relación uno a muchos con Maquina
        public ICollection<Maquina> Maquinas { get; set; }

        // Relación uno a muchos con Ejercicio
        public ICollection<Ejercicio> Ejercicios { get; set; }
    }

}
