﻿using System.ComponentModel.DataAnnotations;

namespace ProyectoEjemploAPPCompleta.Models
{
    public class Socio
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre es obligatorio")]
        [StringLength(100, ErrorMessage = "El nombre no puede tener más de 100 caracteres")]
        public string Nombre { get; set; }

        [Required(ErrorMessage = "El documento de identidad es obligatorio")]
        public string DocumentoIdentidad { get; set; }

        // Relación uno a muchos con SocioRutina
        public ICollection<SocioRutina> SocioRutinas { get; set; }
    }

}
