﻿using EjemploAPPCompleta.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ProyectoEjemploAPPCompleta.Models
{
    public class RutinaEjercicio
    {
        [Required(ErrorMessage = "El ID de la rutina es obligatorio")]
        public int IdRutina { get; set; }

        [Required(ErrorMessage = "El ID del ejercicio es obligatorio")]
        public int IdEjercicio { get; set; }

        [Required(ErrorMessage = "El número de repeticiones es obligatorio")]
        public int Repeticiones { get; set; }

        [Required(ErrorMessage = "El número de series es obligatorio")]
        public int Series { get; set; }

        [ForeignKey("IdRutina")]
        [ValidateNever]
        public Rutina Rutina { get; set; }

        [ForeignKey("IdEjercicio")]
        [ValidateNever]
        public Ejercicio Ejercicio { get; set; }
    }

}
