﻿using EjemploAPPCompleta.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ProyectoEjemploAPPCompleta.Models
{
    public class SocioRutina
    {
        [Required(ErrorMessage = "El ID del socio es obligatorio")]
        public int IdSocio { get; set; }

        [Required(ErrorMessage = "El ID de la rutina es obligatorio")]
        public int IdRutina { get; set; }

        [Required(ErrorMessage = "La fecha de inicio es obligatoria")]
        public DateTime FechaInicio { get; set; }

        [ForeignKey("IdSocio")]
        [ValidateNever]
        public required Socio Socio { get; set; }

        [ForeignKey("IdRutina")]
        [ValidateNever]
        public required Rutina Rutina { get; set; }
    }

}
