﻿using System.ComponentModel.DataAnnotations;

namespace ProyectoEjemploAPPCompleta.Models
{
    public class Local
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre del local es obligatorio")]
        [StringLength(100, ErrorMessage = "El nombre no puede tener más de 100 caracteres")]
        public string Nombre { get; set; }

        [Required(ErrorMessage = "La dirección es obligatoria")]
        [StringLength(200, ErrorMessage = "La dirección no puede tener más de 200 caracteres")]
        public string Direccion { get; set; }

        // Relación uno a muchos con Maquina
        public ICollection<Maquina> MaquinasPosibles { get; set; }
    }

}
