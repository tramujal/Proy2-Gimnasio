﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace EjemploAPPCompleta.Models
{
    //public class VehiculoDueno
    //{
    //	[ForeignKey("Dueno")]
    //	[Required(ErrorMessage ="El dueño es obligatorio")]
    //	public int DuenoId { get; set; }
    //	[ValidateNever]
    //	public Dueno Dueno { get; set; }

    //	[ForeignKey("Vehiculo")]
    //	[Required(ErrorMessage ="El vehículo es obligatorio")]
    //	public string VehiculoMatricula { get; set; }
    //	[ValidateNever]
    //	public Vehiculo Vehiculo { get; set; }

    //	[Required(ErrorMessage = "La fecha es obligatoria")]
    //	public DateTime FechaDesde { get; set; }

    //	[NotMapped]
    //	public List<SelectListItem> VehiculosPosibles;
    //	[NotMapped]
    //	public List<SelectListItem> DuenosPosibles;
    //}
    public class RutinaControl
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El ID de la rutina es obligatorio")]
        public int IdRutina { get; set; }

        [Required(ErrorMessage = "La fecha de control es obligatoria")]
        public DateTime FechaControl { get; set; }

        [Required(ErrorMessage = "El comentario es obligatorio")]
        [StringLength(500, ErrorMessage = "El comentario no puede tener más de 500 caracteres")]
        public string Comentario { get; set; }

        [ForeignKey("IdRutina")]
        [ValidateNever]
        public Rutina Rutina { get; set; }
    }
}

