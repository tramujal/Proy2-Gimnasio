﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ProyectoEjemploAPPCompleta.Models
{
    public class Maquina
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre de la máquina es obligatorio")]
        [StringLength(100, ErrorMessage = "El nombre no puede tener más de 100 caracteres")]
        public string Nombre { get; set; }

        [Required(ErrorMessage = "El ID del local es obligatorio")]
        public int IdLocal { get; set; }

        [Required(ErrorMessage = "El ID del tipo de máquina es obligatorio")]
        public int IdTipoMaq { get; set; }

        [ForeignKey("IdLocal")]
        [ValidateNever]
        public Local Local { get; set; }

        [ForeignKey("IdTipoMaq")]
        [ValidateNever]
        public TipoMaquina TipoMaquinaPosibles { get; set; }

        // Relación uno a muchos con RutinaEjercicio
        public ICollection<RutinaEjercicio> RutinaEjercicios { get; set; }
    }

}
