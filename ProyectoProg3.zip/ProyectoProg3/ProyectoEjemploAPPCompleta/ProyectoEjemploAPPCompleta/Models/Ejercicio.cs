﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ProyectoEjemploAPPCompleta.Models
{
    public class Ejercicio
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre del ejercicio es obligatorio")]
        [StringLength(100, ErrorMessage = "El nombre no puede tener más de 100 caracteres")]
        public string Nombre { get; set; }

        [Required(ErrorMessage = "El ID del tipo de máquina es obligatorio")]
        public int IdTipoMaq { get; set; }

        [ForeignKey("IdTipoMaq")]
        [ValidateNever]
        public TipoMaquina TipoMaquina { get; set; }

        // Relación muchos a muchos con RutinaEjercicio
        public ICollection<RutinaEjercicio> RutinaEjercicios { get; set; }
    }

}
