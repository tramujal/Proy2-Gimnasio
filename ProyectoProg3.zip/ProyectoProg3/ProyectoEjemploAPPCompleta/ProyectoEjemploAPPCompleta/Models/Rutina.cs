﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using ProyectoEjemploAPPCompleta.Models;

namespace EjemploAPPCompleta.Models
{
    public class Rutina
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre de la rutina es obligatorio")]
        [StringLength(100, ErrorMessage = "El nombre no puede tener más de 100 caracteres")]
        public string Nombre { get; set; }

        // Relación uno a muchos con RutinaEjercicio
        public ICollection<RutinaEjercicio> RutinaEjercicios { get; set; }

        // Relación uno a muchos con SocioRutina
        public ICollection<SocioRutina> SocioRutinas { get; set; }

        // Relación uno a muchos con RutinaControl
        public ICollection<RutinaControl> RutinaControles { get; set; }
    }
}

